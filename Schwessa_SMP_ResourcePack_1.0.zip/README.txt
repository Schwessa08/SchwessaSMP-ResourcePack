SCHWESSA SMP - Resource Pack
Minecraft 1.21.1
Resource pack format: 34

Bu ilk sürümde özel ejderha glyph'i hazırlanmıştır.
Glyph karakteri: U+E000

Bir sonraki adımda scoreboard başlığına bu glyph'i ve mor/cyan tasarımı bağlayacağız.
